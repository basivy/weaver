import { useState } from 'react'

import './App.css'
import Slideshow from './Slideshow'
function App() {
  const [count, setCount] = useState(0)
  
  return (
    <>
          
 
<body>

 <style>
 @import url('https://fonts.googleapis.com/css2?family=Kanit:wght@200;300&display=swap');
 </style>

<div class="container">
  <header>
  <h1 className='Logo'>Weaverbase</h1>
  <nav >
     <ul className='Navbar'>
        <li className='pick'>Home</li>
        <li className='pick'>About</li>
        <li className='pick'>Service</li>
        <li className='pick'>Products</li>
        <li className='pick'>Contact</li>             
        </ul>
  </nav>

  <article className='Inovative'>
    <h1>An Inovative</h1>
     <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy
     text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
     It has survived not only five centuries,</p>
  </article>
  </header>



  <article className='About'>
    <h1>About</h1>
     <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard 
     dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
     It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged.</p>
  </article>
  
                 
  <section className='website'>
    <nav id="grad1">
            
    </nav>
    <article className='Welcome'>
      <div >
      <h1 className='welcome-fonth1'>Welcome to our website</h1>
         <p className='welcome-fontp'>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard 
         dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
         It has survived not only five centuries,</p>
      </div>
    </article>

  </section>








  <section className='Services'>
    <nav >
    <h1>Services</h1>
         <ul className='Services-product'>
          <li className='Services-li'><h1>Machine learning</h1>
          <p>Statistical learning" redirects here. For statistical learning in linguistics</p></li>
          <li className='Services-li'><h1>Machine learning</h1>
          <p>Statistical learning" redirects here. For statistical learning in linguistics</p></li>
          <li className='Services-li'><h1>Machine learning</h1>
          <p>Statistical learning" redirects here. For statistical learning in linguistics</p></li>
         </ul>
    </nav>


  </section>


  <section className='Products'>
    <nav >
    <h1>Products</h1>
         <ul className='product-se'>
          <li className='pro-grid'><h1>Machine learning</h1>
          <p>Statistical learning" redirects here. For statistical learning in linguistics</p></li>
          <li className='pro-grid'><h1>Machine learning</h1>
          <p>Statistical learning" redirects here. For statistical learning in linguistics</p></li>
          <li className='pro-grid'><h1>Machine learning</h1>
          <p>Statistical learning" redirects here. For statistical learning in linguistics</p></li>
          <li className='pro-grid'><h1>Machine learning</h1>
          <p>Statistical learning" redirects here. For statistical learning in linguistics</p></li>
          <li className='pro-grid'><h1>Machine learning</h1>
          <p>Statistical learning" redirects here. For statistical learning in linguistics</p></li>
          <li className='pro-grid'><h1>Machine learning</h1>
          <p>Statistical learning" redirects here. For statistical learning in linguistics</p></li>
         </ul>
    </nav>


  </section>

  <section className='Our'>
    <nav >
    <h1>Our Clients</h1>
         <nav>
          <Slideshow></Slideshow>
         </nav>
    </nav>


  </section>

  <section className='Contact'>
    <nav >
    
         <button>Contact</button>
    </nav>


  </section>


  <section className='Our'>
    <nav >

         <ul className='product-se'>
          <li>Facebook</li>
          <li>instagram</li>
          <li>Line</li>
         </ul>
    </nav>


  </section>


  <footer>© 2022 Copyright: Weaverbase.com</footer>



</div>
</body>

    </>
  )
}

export default App
